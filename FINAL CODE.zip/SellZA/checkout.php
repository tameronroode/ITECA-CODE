<?php

session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Please sign in to place an order.';
    header('Location: products.php');
    exit;
}
$user_id = (int) $_SESSION['user_id'];


$stmt = $conn->prepare("
    SELECT p.product_id, p.name, p.price, p.image, c.quantity
      FROM cart_items c
      JOIN products p ON c.product_id = p.product_id
     WHERE c.user_id = ?
     ORDER BY c.added_at DESC
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();


if (empty($items)) {
    include 'header.php';
    echo '<main class="container my-5">';
    echo '<h2>Your Cart Is Empty</h2>';
    echo '<p class="text-muted">Add some products first, then come back here to check out.</p>';
    echo '</main>';
    include 'footer.php';
    exit;
}


$errors = [];
$ship_address  = '';
$ship_city     = '';
$ship_province = '';
$ship_postal   = '';
$ship_country  = '';
$ship_phone    = '';
$card_name     = '';
$card_number   = '';
$exp_month     = '';
$exp_year      = '';
$cvv           = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     
    $ship_address  = trim($_POST['ship_address']  ?? '');
    $ship_city     = trim($_POST['ship_city']     ?? '');
    $ship_province = trim($_POST['ship_province'] ?? '');
    $ship_postal   = trim($_POST['ship_postal']   ?? '');
    $ship_country  = trim($_POST['ship_country']  ?? '');
    $ship_phone    = trim($_POST['ship_phone']    ?? '');

    
    $card_name    = trim($_POST['card_name']   ?? '');
    $card_number  = trim($_POST['card_number'] ?? '');
    $exp_month    = trim($_POST['exp_month']   ?? '');
    $exp_year     = trim($_POST['exp_year']    ?? '');
    $cvv          = trim($_POST['cvv']         ?? '');

    
    if ($ship_address==='')  $errors['ship_address']  = 'Street address is required.';
    if ($ship_city==='')     $errors['ship_city']     = 'City is required.';
    if ($ship_province==='') $errors['ship_province'] = 'Province/state is required.';
    if ($ship_postal==='')   $errors['ship_postal']   = 'Postal code is required.';
    if ($ship_country==='')  $errors['ship_country']  = 'Country is required.';
    if ($ship_phone==='')    $errors['ship_phone']    = 'Phone number is required.';

    if ($card_name==='')     $errors['card_name']     = 'Cardholder name is required.';
    if (!preg_match('/^\d{13,19}$/', $card_number)) {
        $errors['card_number'] = 'Enter a valid card number.';
    }
    if (!preg_match('/^(0[1-9]|1[0-2])$/', $exp_month)) {
        $errors['exp_month'] = 'Invalid month.';
    }
    if (!preg_match('/^\d{2,4}$/', $exp_year)) {
        $errors['exp_year'] = 'Invalid year.';
    }
    if (!preg_match('/^\d{3,4}$/', $cvv)) {
        $errors['cvv'] = 'Invalid CVV.';
    }

    if (empty($errors)) {
        $conn->begin_transaction();
        try {
            
            $ins = $conn->prepare("INSERT INTO orders (user_id) VALUES (?)");
            $ins->bind_param('i', $user_id);
            $ins->execute();
            $order_id = $conn->insert_id;
            $ins->close();

            
            $oiStmt     = $conn->prepare("
                INSERT INTO order_items 
                  (order_id, product_id, quantity, price)
                VALUES (?,?,?,?)
            ");
            $updProd    = $conn->prepare("UPDATE products SET status='sold' WHERE product_id = ?");
            $getSeller  = $conn->prepare("SELECT user_id FROM products WHERE product_id = ?");
            $notifStmt  = $conn->prepare("
                INSERT INTO notifications
                  (user_id, product_id, order_id, message)
                VALUES (?,?,?,?)
            ");

            foreach ($items as $it) {
                
                $oiStmt->bind_param('iiid',
                    $order_id,
                    $it['product_id'],
                    $it['quantity'],
                    $it['price']
                );
                $oiStmt->execute();

                
                $updProd->bind_param('i', $it['product_id']);
                $updProd->execute();

                
                $getSeller->bind_param('i', $it['product_id']);
                $getSeller->execute();
                $getSeller->bind_result($seller_id);
                $getSeller->fetch();

                $msg = "Your product “{$it['name']}” sold in order #{$order_id}.";
                $notifStmt->bind_param('iiis',
                    $seller_id,
                    $it['product_id'],
                    $order_id,
                    $msg
                );
                $notifStmt->execute();
            }

            
            $oiStmt->close();
            $updProd->close();
            $getSeller->close();
            $notifStmt->close();

            
            $clr = $conn->prepare("DELETE FROM cart_items WHERE user_id = ?");
            $clr->bind_param('i', $user_id);
            $clr->execute();
            $clr->close();

            $conn->commit();
            $_SESSION['success'] = "Order #{$order_id} placed!";
            header('Location: payment_success.php');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $errors['general'] = 'Checkout failed: ' . $e->getMessage();
        }
    }
}


include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Checkout — SellZA</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<main class="container my-5">

  <h2 class="section-title mb-4">Checkout</h2>

  <?php if (!empty($errors['general'])): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($errors['general']) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <div class="row gy-4">
      
      <div class="col-lg-5">
        <h4>Your Cart</h4>
        <ul class="list-group mb-3">
          <?php foreach ($items as $p): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <strong><?= htmlspecialchars($p['name']) ?></strong><br>
                <small>Qty: <?= $p['quantity'] ?></small>
              </div>
              <span>R <?= number_format($p['price'] * $p['quantity'],2) ?></span>
            </li>
          <?php endforeach; ?>
          <?php $total = array_reduce($items, fn($s,$i)=>$s+$i['price']*$i['quantity'],0); ?>
          <li class="list-group-item d-flex justify-content-between">
            <strong>Total</strong>
            <strong>R <?= number_format($total, 2) ?></strong>
          </li>
        </ul>
      </div>

      
      <div class="col-lg-7">
        <h4>Shipping Details</h4>
        <div class="row g-3">
          <?php
            $fields = [
              'ship_address'=>'Street Address',
              'ship_city'=>'City',
              'ship_province'=>'Province/State',
              'ship_postal'=>'Postal Code',
              'ship_country'=>'Country',
              'ship_phone'=>'Phone Number'
            ];
            foreach ($fields as $field => $label):
              $val = $$field;
              $err = $errors[$field] ?? '';
          ?>
            <div class="<?= in_array($field, ['ship_address'])?'col-12':'col-md-6' ?>">
              <label class="form-label"><?= $label ?></label>
              <input
                name="<?= $field ?>"
                class="form-control <?= $err?'is-invalid':''?>"
                value="<?= htmlspecialchars($val) ?>"
              >
              <div class="invalid-feedback"><?= $err ?></div>
            </div>
          <?php endforeach; ?>
        </div>

        <hr class="my-4">

    
        <h4>Payment Details</h4>
        <div class="row g-3">
          <?php
            $payFields = [
              'card_name'=>'Cardholder Name',
              'card_number'=>'Card Number',
              'exp_month'=>'Expiry Month (MM)',
              'exp_year'=>'Expiry Year (YY or YYYY)',
              'cvv'=>'CVV'
            ];
            foreach ($payFields as $field=>$label):
              $val = $$field;
              $err = $errors[$field] ?? '';
              $size = in_array($field, ['card_name','card_number'])?'col-md-6':'col-md-4';
          ?>
            <div class="<?= $size ?>">
              <label class="form-label"><?= $label ?></label>
              <input
                name="<?= $field ?>"
                class="form-control <?= $err?'is-invalid':''?>"
                value="<?= htmlspecialchars($val) ?>"
              >
              <div class="invalid-feedback"><?= $err ?></div>
            </div>
          <?php endforeach; ?>
        </div>

        <button type="submit" class="btn-earth btn-lg w-100 mt-4">
          <i class="fas fa-credit-card me-2"></i> Place Order
        </button>
      </div>
    </div>
  </form>
</main>

<script
  src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>
<?php include 'footer.php'; ?>
</body>
</html>

