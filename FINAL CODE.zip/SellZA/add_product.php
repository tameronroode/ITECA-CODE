<?php
session_start();
require __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    header('Location: products.php');
    exit;
}

$error   = '';
$success = '';
$user_id = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    
    if (isset($_POST['delete_product'])) {
        $delId = (int)$_POST['delete_product'];
        $stmt = $conn->prepare("
            DELETE FROM products
             WHERE product_id = ?
               AND user_id    = ?
        ");
        $stmt->bind_param('ii', $delId, $user_id);
        if ($stmt->execute()) {
            $success = 'Product deleted.';
        } else {
            $error = 'Delete failed: ' . $stmt->error;
        }
        $stmt->close();
        
        header('Location: add_product.php');
        exit;
    }

    
    $name        = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price       = floatval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);

    if ($name === '' || $description === '' || $price <= 0 || $category_id <= 0) {
        $error = 'All fields are required and price must be > 0.';
    } elseif (
        !isset($_FILES['image']) ||
        $_FILES['image']['error'] !== UPLOAD_ERR_OK
    ) {
        $error = 'Please upload an image.';
    } else {
      
        $ext      = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('img_', true) . '.' . $ext;
        $target   = __DIR__ . '/uploads/' . $filename;
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $error = 'Failed to save uploaded image.';
        } else {
            
            $stmt = $conn->prepare("
                INSERT INTO products
                  (user_id, category_id, name, description, price, image)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                'iissds',
                $user_id,
                $category_id,
                $name,
                $description,
                $price,
                $filename
            );
            if ($stmt->execute()) {
                
                $stmt->close();
                header('Location: my_listings.php');
                exit;
            } else {
                $error = 'DB error: ' . $stmt->error;
                $stmt->close();
            }
        }
    }
}

$formCats = $conn->query("SELECT category_id, name FROM categories ORDER BY name");


$lst = $conn->prepare("
    SELECT product_id, name, price, image
      FROM products
     WHERE user_id = ?
  ORDER BY created_at DESC
");
$lst->bind_param('i', $user_id);
$lst->execute();
$myListings = $lst->get_result()->fetch_all(MYSQLI_ASSOC);
$lst->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Add Product — SellZA</title>

  
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
  <?php include 'header.php'; ?>

  <main class="container my-5">
    <h2 class="section-title mb-4">Add New Product</h2>

    
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    
    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Product Name</label>
        <input
          type="text"
          name="name"
          class="form-control"
          value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
          required
        >
      </div>

      <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea
          name="description"
          class="form-control"
          rows="3"
          required
        ><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
      </div>

      <div class="mb-3">
        <label class="form-label">Price (R)</label>
        <input
          type="number"
          name="price"
          step="0.01"
          class="form-control"
          value="<?= htmlspecialchars($_POST['price'] ?? '') ?>"
          required
        >
      </div>

      <div class="mb-3">
        <label class="form-label">Category</label>
        <select name="category_id" class="form-select" required>
          <option value="">— choose one —</option>
          <?php while ($cat = $formCats->fetch_assoc()): ?>
            <option
              value="<?= $cat['category_id'] ?>"
              <?= (intval($_POST['category_id'] ?? 0) === (int)$cat['category_id'])
                    ? 'selected' : '' ?>
            >
              <?= htmlspecialchars($cat['name']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Image</label>
        <input
          type="file"
          name="image"
          accept="image/*"
          class="form-control"
          required
        >
      </div>

      <button type="submit" class="btn btn-earth">
        <i class="fas fa-plus me-1"></i> Add Product
      </button>
    </form>

    <hr class="my-5">

    
    <h3 class="mb-4">My Listings</h3>
    <?php if (empty($myListings)): ?>
      <p class="text-muted">You have no products listed yet.</p>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($myListings as $p): ?>
          <div class="col-sm-6 col-lg-4">
            <div class="card-earth">
              <div class="card-img-container">
                <img
                  src="uploads/<?= htmlspecialchars($p['image']) ?>"
                  alt="<?= htmlspecialchars($p['name']) ?>"
                >
              </div>
              <div class="card-body d-flex flex-column">
                <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
                <p class="card-text fw-bold">
                  R <?= number_format($p['price'], 2) ?>
                </p>
                <div class="mt-auto d-flex justify-content-between">
                  <a
                    href="edit_product.php?id=<?= $p['product_id'] ?>"
                    class="btn btn-outline-earth btn-sm"
                  >
                    <i class="fa fa-edit"></i>
                  </a>
                  <form method="post" onsubmit="return confirm('Delete this product?');">
                    <input
                      type="hidden"
                      name="delete_product"
                      value="<?= $p['product_id'] ?>"
                    >
                    <button class="btn btn-outline-danger btn-sm">
                      <i class="fa fa-trash"></i>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </main>

  <?php include 'footer.php'; ?>

  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>
