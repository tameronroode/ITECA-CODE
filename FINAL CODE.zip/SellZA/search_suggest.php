<?php
require __DIR__ . '/includes/db.php';
header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
if ($q === '') {
  echo json_encode([]);
  exit;
}

$stmt = $conn->prepare("
  SELECT name
    FROM products
   WHERE name LIKE ?
   ORDER BY name
   LIMIT 5
");
$like = "%{$q}%";
$stmt->bind_param('s', $like);
$stmt->execute();

$res = $stmt->get_result();
$suggestions = [];
while ($row = $res->fetch_assoc()) {
    $suggestions[] = $row['name'];
}

echo json_encode($suggestions);
