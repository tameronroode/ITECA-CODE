<?php
session_start();
require __DIR__ . '/includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$me = (int)$_SESSION['user_id'];
$chatWith = isset($_GET['user']) ? (int)$_GET['user'] : 0;
$searchTerm = isset($_GET['q']) ? trim($_GET['q']) : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message']) && !empty($_POST['recipient'])) {
    $to = (int)$_POST['recipient'];
    $content = trim($_POST['message']);
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, recipient_id, content) VALUES (?, ?, ?)");
    $stmt->bind_param('iis', $me, $to, $content);
    $stmt->execute();
    $stmt->close();
    header("Location: messenger.php?user={$to}");
    exit;
}
if (isset($_GET['ajax']) && $chatWith > 0) {
    $stmt = $conn->prepare("SELECT sender_id, content, sent_at FROM messages WHERE (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?) ORDER BY sent_at ASC");
    $stmt->bind_param('iiii', $me, $chatWith, $chatWith, $me);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($res);
    exit;
}
$contacts = [];
if ($searchTerm === '') {
    $res = $conn->prepare("SELECT user_id, name FROM users WHERE user_id != ? ORDER BY name");
    $res->bind_param('i', $me);
    $res->execute();
    $contacts = $res->get_result()->fetch_all(MYSQLI_ASSOC);
    $res->close();
} else {
    $likeTerm = "%" . $searchTerm . "%";
    $res = $conn->prepare("SELECT user_id, name FROM users WHERE user_id != ? AND name LIKE ? ORDER BY name");
    $res->bind_param('is', $me, $likeTerm);
    $res->execute();
    $contacts = $res->get_result()->fetch_all(MYSQLI_ASSOC);
    $res->close();
}
$messages = [];
if ($chatWith > 0) {
    $stmt = $conn->prepare("SELECT sender_id, content, sent_at FROM messages WHERE (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?) ORDER BY sent_at ASC");
    $stmt->bind_param('iiii', $me, $chatWith, $chatWith, $me);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
if ($chatWith > 0) {
    $stmt = $conn->prepare("SELECT name FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $chatWith);
    $stmt->execute();
    $stmt->bind_result($chatName);
    $stmt->fetch();
    $stmt->close();
} else {
    $chatName = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Chat – SellZA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .chat-container { display: flex; height: 80vh; margin: 1rem; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; }
    .contacts-panel { width: 280px; border-right: 1px solid #ccc; display: flex; flex-direction: column; }
    .contacts-search { padding: 0.5rem; }
    .contacts-search .input-group .form-control-sm { font-size: 0.9rem; }
    .contacts-search .btn-earth.btn-sm { padding: 0.3rem 0.6rem; font-size: 0.9rem; }
    .contacts-list { flex: 1; overflow-y: auto; list-style: none; margin: 0; padding: 0; }
    .contacts-list li { padding: 0.75rem 1rem; display: flex; align-items: center; cursor: pointer; }
    .contacts-list li.active, .contacts-list li:hover { background-color: #f0e7df; }
    .contacts-list li .status-dot { width: 8px; height: 8px; border-radius: 50%; background: #4caf50; margin-right: 0.5rem; }
    .contacts-list li .name { font-weight: 500; color: #5d4037; }
    .chat-panel { flex: 1; display: flex; flex-direction: column; }
    .chat-header { padding: 0.75rem 1rem; border-bottom: 1px solid #ccc; background: #f7f0e8; color: #5d4037; font-weight: 500; }
    .chat-box { flex: 1; padding: 1rem; overflow-y: auto; background: #fcf5ee; }
    .msg { margin-bottom: 1rem; max-width: 60%; padding: 0.6rem 1rem; border-radius: 20px; position: relative; }
    .msg.me { margin-left: auto; background: #a1887f; color: #fff; border-bottom-right-radius: 4px; }
    .msg.them { margin-right: auto; background: #fff; border: 1px solid #ccc; border-bottom-left-radius: 4px; }
    .msg small { display: block; font-size: 0.75rem; color: #666; margin-top: 0.3rem; }
    .chat-input { padding: 0.5rem 1rem; border-top: 1px solid #ccc; background: #f7f0e8; }
    .chat-input .btn-earth { border-top-left-radius: 0; border-bottom-left-radius: 0; }
  </style>
</head>
<body>
  <?php include 'header.php'; ?>

  <div class="chat-container">
    <div class="contacts-panel">
      <form method="get" class="contacts-search">
        <div class="input-group">
          <input type="text" name="q" value="<?= htmlspecialchars($searchTerm) ?>" class="form-control form-control-sm" placeholder="Search users…" autocomplete="off">
          <button class="btn btn-earth btn-sm" type="submit"><i class="fas fa-search"></i></button>
        </div>
        <?php if ($chatWith): ?><input type="hidden" name="user" value="<?= $chatWith ?>"><?php endif; ?>
      </form>

      <ul class="contacts-list">
        <?php if (empty($contacts)): ?>
          <li class="text-center text-muted">No users found.</li>
        <?php else: ?>
          <?php foreach ($contacts as $u): ?>
            <li class="<?= ($u['user_id'] === $chatWith) ? 'active' : '' ?>">
              <span class="status-dot"></span>
              <a href="messenger.php?user=<?= $u['user_id'] ?><?php if ($searchTerm!=='') echo '&q=' . urlencode($searchTerm); ?>" class="name"><?= htmlspecialchars($u['name']) ?></a>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>

    <div class="chat-panel">
      <?php if (!$chatWith): ?>
        <div class="d-flex align-items-center justify-content-center flex-grow-1">
          <p class="text-muted">Select a user to start chatting.</p>
        </div>
      <?php else: ?>
        <div class="chat-header"><?= htmlspecialchars($chatName) ?> <span class="text-success">(Available)</span></div>
        <div id="chat-box" class="chat-box">
          <?php if (empty($messages)): ?>
            <p class="text-center text-muted">No messages yet. Say hello!</p>
          <?php else: ?>
            <?php foreach ($messages as $m): ?>
              <?php $who = ($m['sender_id'] === $me) ? 'me' : 'them'; ?>
              <div class="msg <?= $who ?>">
                <?= nl2br(htmlspecialchars($m['content'])) ?>
                <small><?= date("Y-m-d H:i", strtotime($m['sent_at'])) ?></small>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
        <div class="chat-input">
          <form method="post" action="messenger.php?user=<?= $chatWith ?>">
            <input type="hidden" name="recipient" value="<?= $chatWith ?>">
            <div class="input-group">
              <input type="text" name="message" class="form-control" placeholder="Type your message…" autocomplete="off" required>
              <button class="btn-earth btn" type="submit"><i class="fas fa-paper-plane"></i></button>
            </div>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <script>
    const chatWithId = <?= $chatWith ?>;
    function fetchMessages() {
      if (!chatWithId) return;
      fetch(`messenger.php?user=${chatWithId}&ajax=1`)
        .then(res => res.json())
        .then(data => {
          const box = document.getElementById('chat-box');
          box.innerHTML = '';
          data.forEach(m => {
            const div = document.createElement('div');
            div.className = 'msg ' + (m.sender_id === <?= $me ?> ? 'me' : 'them');
            div.innerHTML = m.content.replace(/\n/g, '<br>') +
              `<small>${new Date(m.sent_at).toLocaleString()}</small>`;
            box.appendChild(div);
          });
          box.scrollTop = box.scrollHeight;
        });
    }
    setInterval(fetchMessages, 3000);
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

