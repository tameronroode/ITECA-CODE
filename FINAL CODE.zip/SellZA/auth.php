<?php


session_start();
require __DIR__ . '/includes/db.php';


$action = $_POST['action'] ?? '';

if ($action === 'login') {
    
    $email    = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT user_id, name, password, role FROM users WHERE email=?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->bind_result($uid, $name, $hash, $role);
    if ($stmt->fetch() && password_verify($password, $hash)) {
        $_SESSION['user_id'] = $uid;
        $_SESSION['name']    = $name;
        $_SESSION['role']    = $role;
        $_SESSION['success'] = 'Logged in successfully.';
    } else {
        $_SESSION['error'] = 'Invalid email or password.';
    }
    $stmt->close();

} elseif ($action === 'register') {
    
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $phone    = $_POST['phone']    ?? '';
    $address  = $_POST['address']  ?? '';
    $password = $_POST['password'];
    $role     = $_POST['role'];

    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email=?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->bind_result($cnt);
    $stmt->fetch();
    $stmt->close();

    if ($cnt > 0) {
        $_SESSION['error'] = 'That email is already registered.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("
            INSERT INTO users (name, email, phone, address, password, role)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param('ssssss',
            $name, $email, $phone, $address, $hash, $role
        );
        if ($stmt->execute()) {
            $_SESSION['success'] = 'Registration successful! You can now log in.';
        } else {
            $_SESSION['error'] = 'Something went wrong.';
        }
        $stmt->close();
    }
}


$redirect = $_SERVER['HTTP_REFERER'] ?? 'products.php';
header("Location: $redirect");
exit;

