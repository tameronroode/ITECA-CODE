<?php

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$user_id = (int) $_SESSION['user_id'];


$error   = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $bio     = trim($_POST['bio'] ?? '');
    $role    = in_array($_POST['role'] ?? '', ['buyer','seller']) ? $_POST['role'] : 'buyer';

    if ($name === '' || $email === '') {
        $error = 'Name and email are required.';
    } else {
        
        $avatar_filename = $_POST['current_avatar'] ?? '';
        if (!empty($_FILES['avatar']['name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $ext   = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
            $newAv = uniqid('av_', true) . '.' . $ext;
            $target = __DIR__ . '/uploads/' . $newAv;
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target)) {
                $avatar_filename = $newAv;
            }
        }
        
        $stmt = $conn->prepare("
          UPDATE users
             SET name=?, email=?, phone=?, address=?,
                 bio=?, role=?, avatar=?
           WHERE user_id=?
        ");
        $stmt->bind_param(
            'sssssssi',
            $name, $email, $phone, $address,
            $bio, $role, $avatar_filename,
            $user_id
        );
        if ($stmt->execute()) {
            $_SESSION['name'] = $name;
            $_SESSION['role'] = $role;
            $success = 'Profile updated successfully!';
        } else {
            $error = 'Database error: ' . $stmt->error;
        }
        $stmt->close();
    }
}


$stmt = $conn->prepare("
    SELECT name, email, phone, address, bio, role, avatar
      FROM users
     WHERE user_id = ?
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($name, $email, $phone, $address, $bio, $role, $avatar);
$stmt->fetch();
$stmt->close();

$address = $address ?? '';
$bio     = $bio     ?? '';

$orders = [];
$notifications = [];
$listings = [];

if ($role === 'buyer') {
    $ost = $conn->prepare("
        SELECT order_id, created_at
          FROM orders
         WHERE user_id = ?
      ORDER BY created_at DESC
    ");
    $ost->bind_param('i', $user_id);
    $ost->execute();
    $orRes = $ost->get_result();
    while ($o = $orRes->fetch_assoc()) {
        $itStmt = $conn->prepare("
          SELECT p.name, p.image, oi.quantity, oi.price
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
           WHERE oi.order_id = ?
        ");
        $itStmt->bind_param('i', $o['order_id']);
        $itStmt->execute();
        $items = $itStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $itStmt->close();
        $orders[] = [
            'order_id'   => $o['order_id'],
            'created_at' => $o['created_at'],
            'items'      => $items
        ];
    }
    $ost->close();
} else {
   
    $nstmt = $conn->prepare("
      SELECT id, message, is_read, created_at
        FROM notifications
       WHERE user_id = ?
    ORDER BY created_at DESC
    ");
    $nstmt->bind_param('i', $user_id);
    $nstmt->execute();
    $notifications = $nstmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $nstmt->close();

   
    $lst = $conn->prepare("
        SELECT product_id, name, price, image, status
          FROM products
         WHERE user_id = ?
      ORDER BY created_at DESC
    ");
    $lst->bind_param('i', $user_id);
    $lst->execute();
    $listings = $lst->get_result()->fetch_all(MYSQLI_ASSOC);
    $lst->close();
}


include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>My Profile — SellZA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<div class="container my-5">

  
  <div class="text-center mb-5">
    <?php if ($avatar): ?>
      <img src="uploads/<?= htmlspecialchars($avatar) ?>"
           class="rounded-circle mb-3"
           width="120" height="120" alt="Avatar">
    <?php else: ?>
      <i class="fas fa-user-circle fa-8x text-secondary mb-3"></i>
    <?php endif; ?>
    <h3><?= htmlspecialchars($name) ?></h3>
    <p class="text-muted"><?= ucfirst(htmlspecialchars($role)) ?></p>
  </div>

  
  <div class="row g-4 mb-5">
    <div class="col-sm-6 col-md-4">
      <a href="#edit-profile" class="card shadow-sm text-center text-decoration-none h-100">
        <div class="card-body">
          <i class="fas fa-user-edit fa-2x text-earth mb-2"></i>
          <h6 class="mb-0">Edit Profile</h6>
        </div>
      </a>
    </div>

    <?php if ($role === 'buyer'): ?>

      <div class="col-sm-6 col-md-4">
        <a href="#order-history" class="card shadow-sm text-center text-decoration-none h-100">
          <div class="card-body">
            <i class="fas fa-box-open fa-2x text-earth mb-2"></i>
            <h6 class="mb-0">Order History</h6>
          </div>
        </a>
      </div>

    <?php else: /* seller */ ?>
      <div class="col-sm-6 col-md-4">
        <a href="#notifications" class="card shadow-sm text-center text-decoration-none h-100">
          <div class="card-body">
            <i class="fas fa-bell fa-2x text-earth mb-2"></i>
            <h6 class="mb-0">
              Notifications
              <?php
                $unread = count(array_filter($notifications, fn($n)=>!$n['is_read']));
                if ($unread): ?>
                  <span class="badge bg-danger ms-1"><?= $unread ?></span>
              <?php endif; ?>
            </h6>
          </div>
        </a>
      </div>
      
      <div class="col-sm-6 col-md-4">
        <a href="#my-listings" class="card shadow-sm text-center text-decoration-none h-100">
          <div class="card-body">
            <i class="fas fa-th-list fa-2x text-earth mb-2"></i>
            <h6 class="mb-0">My Listings</h6>
          </div>
        </a>
      </div>
      
      <div class="col-sm-6 col-md-4">
        <a href="add_product.php" class="card shadow-sm text-center text-decoration-none h-100">
          <div class="card-body">
            <i class="fas fa-plus-circle fa-2x text-earth mb-2"></i>
            <h6 class="mb-0">Add Product</h6>
          </div>
        </a>
      </div>
    <?php endif; ?>
  </div>

  
  <div id="edit-profile" class="mb-5">
    <h4>Edit Profile</h4>
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="mt-3">
      <input type="hidden" name="update_profile" value="1">
      <input type="hidden" name="current_avatar" value="<?= htmlspecialchars($avatar) ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Full Name</label>
          <input name="name" type="text" class="form-control" value="<?= htmlspecialchars($name) ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Email</label>
          <input name="email" type="email" class="form-control" value="<?= htmlspecialchars($email) ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Phone</label>
          <input name="phone" type="text" class="form-control" value="<?= htmlspecialchars($phone) ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Address</label>
          <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($address) ?></textarea>
        </div>
        <div class="col-md-4">
          <label class="form-label">Account Type</label>
          <select name="role" class="form-select">
            <option value="buyer"  <?= $role==='buyer' ? 'selected' : '' ?>>Buyer</option>
            <option value="seller" <?= $role==='seller' ? 'selected' : '' ?>>Seller</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Profile Picture</label>
          <input name="avatar" type="file" accept="image/*" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Bio</label>
          <textarea name="bio" class="form-control" rows="2"><?= htmlspecialchars($bio) ?></textarea>
        </div>
      </div>
      <button class="btn btn-earth mt-4">
        <i class="fas fa-save me-1"></i> Save Changes
      </button>
    </form>
  </div>

  <?php if ($role === 'buyer'): ?>
    
    <div id="order-history" class="mb-5">
      <h4>Order History</h4>
      <?php if (empty($orders)): ?>
        <p class="text-muted">You have no past orders.</p>
      <?php else: ?>
        <?php foreach ($orders as $o): ?>
          <div class="mb-4">
            <h5>
              Order #<?= $o['order_id'] ?>
              <small class="text-muted">on <?= date('F j, Y', strtotime($o['created_at'])) ?></small>
            </h5>
            <div class="row g-3">
              <?php foreach ($o['items'] as $it): ?>
                <div class="col-sm-6 col-md-4">
                  <div class="card-earth">
                    <div class="card-img-container">
                      <img src="uploads/<?= htmlspecialchars($it['image']) ?>" alt="">
                    </div>
                    <div class="card-body d-flex flex-column">
                      <h6 class="card-title"><?= htmlspecialchars($it['name']) ?></h6>
                      <p class="card-text">Qty: <?= $it['quantity'] ?></p>
                      <p class="card-text fw-bold">R <?= number_format($it['price'] * $it['quantity'], 2) ?></p>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <hr>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  <?php else: ?>
    
    <div id="notifications" class="mb-5">
      <h4>Notifications</h4>
      <?php if (empty($notifications)): ?>
        <p class="text-muted">No notifications.</p>
      <?php else: ?>
        <ul class="list-group">
          <?php foreach ($notifications as $n): ?>
            <li class="list-group-item d-flex justify-content-between align-items-start">
              <div>
                <?= htmlspecialchars($n['message']) ?>
                <?php if (!$n['is_read']): ?>
                  <span class="badge bg-warning text-dark ms-2">New</span>
                <?php endif; ?>
              </div>
              <small class="text-muted"><?= date('M j, Y H:i', strtotime($n['created_at'])) ?></small>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    
    <div id="my-listings" class="mb-5">
      <h4>My Listings</h4>
      <?php if (empty($listings)): ?>
        <p class="text-muted">You have no products listed yet.</p>
      <?php else: ?>
        <div class="row g-4">
          <?php foreach ($listings as $p): ?>
            <div class="col-sm-6 col-lg-4">
              <div class="card-earth position-relative">
                <?php if ($p['status'] === 'sold'): ?>
                  <span class="badge bg-danger position-absolute top-0 end-0 m-2">Sold</span>
                <?php endif; ?>
                <div class="card-img-container">
                  <img src="uploads/<?= htmlspecialchars($p['image']) ?>" alt="">
                </div>
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
                  <p class="card-text fw-bold">R <?= number_format($p['price'], 2) ?></p>
                  <div class="mt-auto d-flex gap-2">
                    <a href="edit_product.php?id=<?= $p['product_id'] ?>" class="btn btn-outline-earth btn-sm" title="Edit">
                      <i class="fa fa-edit"></i>
                    </a>
                    <a href="product_detail.php?id=<?= $p['product_id'] ?>" class="btn-earth btn-sm" title="View">
                      <i class="fa fa-eye"></i>
                    </a>
                    <form method="post" onsubmit="return confirm('Delete this product?');">
                      <input type="hidden" name="delete_product" value="<?= $p['product_id'] ?>">
                      <button class="btn-earth btn-sm" title="Delete">
                        <i class="fa fa-trash"></i>
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

</div>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
