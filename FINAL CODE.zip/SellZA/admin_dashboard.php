<?php
session_start();
require 'includes/db.php';

// Redirect to login if not logged in or not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$name = $_SESSION['name'] ?? 'Admin User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard - SellZA</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <!-- Add Bootstrap CSS and FontAwesome for icons (if used) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm py-2">
  <div class="container-fluid">
    <a class="navbar-brand brand-text" href="products.php">SellZA</a>
    <button
      class="navbar-toggler"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#mainNav"
      aria-label="Toggle navigation"
    >
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle"
            href="#"
            id="catBtn"
            role="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            Categories
          </a>
          <ul class="dropdown-menu" aria-labelledby="catBtn">
            <li><a class="dropdown-item" href="products.php">See All Products</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="products.php?category=4">Accessories</a></li>
            <li><a class="dropdown-item" href="products.php?category=2">Art &amp; Collectibles</a></li>
            <li><a class="dropdown-item" href="products.php?category=8">Baby</a></li>
            <li><a class="dropdown-item" href="products.php?category=10">Bags &amp; Purses</a></li>
            <li><a class="dropdown-item" href="products.php?category=11">Bath &amp; Beauty</a></li>
            <li><a class="dropdown-item" href="products.php?category=12">Books, Films &amp; Music</a></li>
            <li><a class="dropdown-item" href="products.php?category=13">Clothing</a></li>
            <li><a class="dropdown-item" href="products.php?category=3">Craft Supplies &amp; Tools</a></li>
            <li><a class="dropdown-item" href="products.php?category=14">Electronics &amp; Accessories</a></li>
            <li><a class="dropdown-item" href="products.php?category=9">Gifts</a></li>
            <li><a class="dropdown-item" href="products.php?category=1">Home &amp; Living</a></li>
            <li><a class="dropdown-item" href="products.php?category=15">Jewellery</a></li>
            <li><a class="dropdown-item" href="products.php?category=5">Shoes</a></li>
            <li><a class="dropdown-item" href="products.php?category=6">Toys &amp; Games</a></li>
            <li><a class="dropdown-item" href="products.php?category=7">Weddings</a></li>
          </ul>
        </li>
      </ul>

      <form class="d-flex flex-grow-1 me-4" method="get" action="products.php" role="search">
        <input
          class="form-control form-control-lg me-2"
          type="search"
          id="searchInput"
          name="search"
          placeholder="Search for anything…"
          aria-label="Search"
          autocomplete="off"
          list="suggestions"
        />
        <datalist id="suggestions"></datalist>
        <button class="btn btn-earth btn-lg" type="submit">
          <i class="fas fa-search"></i>
        </button>
      </form>

      <ul class="navbar-nav d-flex align-items-center mb-2 mb-lg-0">
        <li class="nav-item">
          <span class="nav-link">Hi, <?= htmlspecialchars($name) ?></span>
        </li>
        <li class="nav-item">
          <a class="nav-link text-danger fw-bold" href="admin_dashboard.php" title="Admin Panel">
            <i class="fas fa-cogs"></i> Admin
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="profile.php" title="My Profile">
            <i class="fas fa-user-circle fa-lg"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="wishlist.php" title="Wishlist">
            <i class="fas fa-heart fa-lg"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="cart.php" title="Cart">
            <i class="fas fa-shopping-cart fa-lg"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="messenger.php" title="Chat">
            <i class="fas fa-comments fa-lg"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php" title="Log Out">
            <i class="fas fa-sign-out-alt fa-lg"></i>
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('searchInput');
  const list  = document.getElementById('suggestions');
  let timer;

  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (!q) return list.innerHTML = '';

    timer = setTimeout(() => {
      fetch('search_suggest.php?q=' + encodeURIComponent(q))
        .then(res => res.json())
        .then(arr => {
          list.innerHTML = '';
          arr.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            list.appendChild(opt);
          });
        })
        .catch(() => { /* silently fail */ });
    }, 300);
  });
});
</script>

<div class="container py-5">
  <h1>Admin Dashboard</h1>
  <ul>
    <li><a href="report_users.php">📋 View Users</a></li>
    <li><a href="report_sales.php">📈 View Sales</a></li>
    <li><a href="report_products.php">🛒 View Products</a></li>
  </ul>
</div>

<!-- Bootstrap JS Bundle (Popper + Bootstrap JS) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
