<?php

$host     = 'sql203.infinityfree.com';
$user     = 'if0_39141206';
$password = 'Evan04Sabrina';
$dbname   = 'if0_39141206_sellza_db';
$port     = 3306;

$conn = new mysqli($host, $user, $password, $dbname, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
