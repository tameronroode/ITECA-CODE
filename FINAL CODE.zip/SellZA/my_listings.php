<?php
session_start();
require __DIR__ . '/includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    header('Location: products.php');
    exit;
}
$user_id = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $pid = (int)$_POST['delete_product'];
    $del = $conn->prepare("
        DELETE FROM products 
         WHERE product_id = ? 
           AND user_id = ?
    ");
    $del->bind_param('ii', $pid, $user_id);
    $del->execute();
    $_SESSION['success'] = 'Product deleted successfully.';
    header('Location: my_listings.php');
    exit;
}

$stmt = $conn->prepare("
    SELECT product_id, name, price, image
      FROM products
     WHERE user_id = ?
  ORDER BY created_at DESC
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$listings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>My Listings — SellZA</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <?php include 'header.php'; ?>

  <main class="container my-5">
    <?php if (!empty($_SESSION['success'])): ?>
      <div class="alert alert-success">
        <?= htmlspecialchars($_SESSION['success']) ?>
      </div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="section-title m-0">My Listings</h2>
      <a href="add_product.php" class="btn btn-earth">
        <i class="fas fa-plus me-1"></i> Add New Product
      </a>
    </div>

    <?php if (empty($listings)): ?>
      <p class="text-center text-muted">You have no products listed yet.</p>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($listings as $p): ?>
          <div class="col-sm-6 col-lg-4">
            <div class="card-earth h-100">
              <div class="card-img-container">
                <img
                  src="uploads/<?= htmlspecialchars($p['image']) ?>"
                  alt="<?= htmlspecialchars($p['name']) ?>"
                >
              </div>
              <div class="card-body d-flex flex-column">
                <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
                <p class="card-text fw-bold">
                  R <?= number_format($p['price'], 2) ?>
                </p>

                <div class="mt-auto d-flex justify-content-between">
                
                  <a
                    href="edit_product.php?id=<?= $p['product_id'] ?>"
                    class="btn-outline-earth btn-sm"
                    title="Edit"
                  >
                    <i class="fas fa-edit"></i>
                  </a>

                  <a
                    href="product_detail.php?id=<?= $p['product_id'] ?>"
                    class="btn-earth btn-sm"
                    title="View"
                  >
                    <i class="fas fa-eye"></i>
                  </a>

                  <form
                    method="post"
                    class="d-inline"
                    onsubmit="return confirm('Are you sure you want to delete this product?');"
                  >
                    <input
                      type="hidden"
                      name="delete_product"
                      value="<?= $p['product_id'] ?>"
                    >
                    <button
                      type="submit"
                      class="btn-earth btn-sm"
                      title="Delete"
                    >
                      <i class="fas fa-trash"></i>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  <?php include 'footer.php'; ?>


  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>

