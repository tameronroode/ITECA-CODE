
<?php
session_start();
require __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Please sign in to use your wishlist.';
    header('Location: products.php');
    exit;
}

$user_id = $_SESSION['user_id'];


if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['product_id'])) {
    $pid = (int)$_POST['product_id'];
    $stmt = $conn->prepare("
        INSERT IGNORE INTO wishlist (user_id, product_id)
        VALUES (?, ?)
    ");
    $stmt->bind_param('ii', $user_id, $pid);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = 'Added to your wishlist!';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_id'])) {
    $rid = (int)$_POST['remove_id'];
    $stmt = $conn->prepare("
        DELETE FROM wishlist WHERE user_id = ? AND product_id = ?
    ");
    $stmt->bind_param('ii', $user_id, $rid);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = 'Removed from wishlist!';
    header('Location: wishlist.php');
    exit;
}


$stmt = $conn->prepare("
    SELECT p.product_id, p.name, p.price, p.image
      FROM wishlist w
      JOIN products p ON w.product_id = p.product_id
     WHERE w.user_id = ?
     ORDER BY w.created_at DESC
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Your Wishlist — SellZA</title>
  
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <?php include 'header.php'; ?>

  <main class="container my-5">
    <h2 class="section-title mb-4">Your Wishlist</h2>

    <?php if (empty($items)): ?>
      <p class="text-center">No items in your wishlist yet.</p>
    <?php else: ?>
      <div class="product-grid d-flex flex-wrap gap-4 justify-content-center">
        <?php foreach ($items as $p): ?>
          <div class="card-earth position-relative">
            <div class="card-img-container">
              <img
                src="uploads/<?= htmlspecialchars($p['image']) ?>"
                alt="<?= htmlspecialchars($p['name']) ?>"
              />
            </div>
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
              <p class="card-text fw-bold">
                R <?= number_format($p['price'], 2) ?>
              </p>
              <a
                href="product_detail.php?id=<?= $p['product_id'] ?>"
                class="btn-earth mt-auto btn-sm me-2"
              >
                <i class="fas fa-eye"></i> View
              </a>
              
              <form method="post" action="wishlist.php" class="d-inline">
                <input type="hidden" name="remove_id" value="<?= $p['product_id'] ?>">
                <button type="submit" class="btn btn-outline-danger btn-sm" title="Remove from Wishlist" onclick="return confirm('Remove this item from your wishlist?');">
                  <i class="fas fa-trash"></i>
                </button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  
  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>

