<?php
session_start();
require __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'buyer') {
    header('Location: products.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];


$stmt = $conn->prepare("
    SELECT order_id, created_at
      FROM orders
     WHERE user_id = ?
  ORDER BY created_at DESC
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

include 'header.php';
?>
<main class="container my-5">
  <h2 class="section-title mb-4">My Purchases</h2>

  <?php if (empty($orders)): ?>
    <p class="text-center text-muted">You have no past orders.</p>
  <?php else: ?>
    <?php foreach ($orders as $o): ?>
      <div class="mb-5">
        <h5>Order #<?= $o['order_id'] ?> 
          <small class="text-muted">
            placed <?= date('F j, Y', strtotime($o['created_at'])) ?>
          </small>
        </h5>
        <div class="row g-3">
          <?php
            
            $stmt2 = $conn->prepare("
              SELECT p.name, p.image, oi.quantity, oi.price
                FROM order_items oi
                JOIN products p 
                  ON oi.product_id = p.product_id
               WHERE oi.order_id = ?
            ");
            $stmt2->bind_param('i', $o['order_id']);
            $stmt2->execute();
            $items = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt2->close();
          ?>

          <?php foreach ($items as $it): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
              <div class="card-earth">
                <div class="card-img-container">
                  <img
                    src="uploads/<?= htmlspecialchars($it['image']) ?>"
                    alt="<?= htmlspecialchars($it['name']) ?>"
                  >
                </div>
                <div class="card-body d-flex flex-column">
                  <h6 class="card-title"><?= htmlspecialchars($it['name']) ?></h6>
                  <p class="card-text">
                    Qty: <?= $it['quantity'] ?>
                  </p>
                  <p class="card-text fw-bold">
                    R <?= number_format($it['price'] * $it['quantity'], 2) ?>
                  </p>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <hr>
    <?php endforeach; ?>
  <?php endif; ?>
</main>
<?php include 'footer.php'; ?>
