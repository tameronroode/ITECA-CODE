<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>About SellZA</title>
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    body {
      background:
        linear-gradient(var(--overlay), var(--overlay)),
        url('assets/images/mountain.jpg') no-repeat center / cover fixed;
      min-height: 100vh;
    }
    .about-container {
      max-width: 750px;
      background: rgba(253,246,239,0.97);
      border-radius: var(--radius, 0.6rem);
      box-shadow: 0 4px 20px rgba(101,67,33,0.09);
      margin: 60px auto;
      padding: 2.5rem 2rem 2rem 2rem;
      color: var(--brown-dark, #4a3728);
    }
    .section-title {
      color: var(--brown-med, #a1742a);
      font-size: 2.2rem;
      font-weight: 700;
      margin-bottom: 1.5rem;
    }
    .about-container ul {
      margin-top: 1rem;
      margin-bottom: 1rem;
    }
    .about-container ul li {
      margin-bottom: 0.7rem;
      font-size: 1.04rem;
      padding-left: 0.1rem;
    }
    .back-arrow {
      position: absolute;
      top: 25px;
      left: 25px;
      font-size: 1.6rem;
      color: var(--brown-med, #a1742a);
      background: rgba(255,255,255,0.82);
      border-radius: 100px;
      padding: 0.4rem 0.8rem 0.4rem 0.6rem;
      text-decoration: none;
      transition: background 0.15s;
      z-index: 50;
      box-shadow: 0 2px 8px rgba(101,67,33,0.08);
    }
    .back-arrow:hover {
      background: var(--brown-light, #e2cbb4);
      color: var(--brown-dark, #4a3728);
      text-decoration: none;
    }
    @media (max-width: 600px) {
      .about-container { padding: 1.2rem 0.7rem; }
      .back-arrow { top: 10px; left: 10px; }
    }
  </style>
</head>
<body>
  <a href="login.php" class="back-arrow" title="Back to Login">
    <i class="fas fa-arrow-left"></i>
  </a>
  <main>
    <div class="about-container">
      <h2 class="section-title">About SellZA</h2>
      <p>
        SellZA is more than just an e-commerce website—it's a growing community built by South Africans, for South Africans. Our platform was created out of a desire to help informal traders, small businesses, and everyday people reach new customers and unlock real opportunities.
      </p>
      <p>
        We know how much passion and creativity goes into the goods that locals make, whether it's handmade crafts, unique clothing, vintage finds, or specialty items you won't see in big stores. At SellZA, we're dedicated to helping those sellers connect directly with buyers who value originality and the personal stories behind every product.
      </p>
      <ul>
        <li>Set up your own store and showcase your products in minutes.</li>
        <li>Communicate directly with buyers and sellers in a safe, friendly environment.</li>
        <li>Manage orders, payments, and deliveries with confidence.</li>
        <li>Be part of a movement that puts local business and community first.</li>
      </ul>
      <p>
        Our mission is to empower local trade—giving people across South Africa an easy way to buy and sell, support their families, and contribute to our country’s growing digital economy.<br>
        Whether you're looking to turn your hobby into a business, support homegrown brands, or just discover something new and meaningful, SellZA welcomes you.
      </p>
      <p>
        <strong>Join us and help shape the future of local online trade. SellZA—empowering local trade, one connection at a time.</strong>
      </p>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

