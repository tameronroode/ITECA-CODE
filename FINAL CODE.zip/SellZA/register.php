<?php

session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: products.php');
    exit;
}

include __DIR__ . '/includes/db.php';


$error   = $_SESSION['error']   ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register – SellZA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height:100vh;">

  <div class="card p-4 shadow-sm" style="max-width:400px; width:100%;">
    <h3 class="text-center mb-4">Create Account</h3>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post" action="auth.php">
      <input type="hidden" name="action" value="register">

      <div class="mb-3">
        <label for="name" class="form-label">Full Name</label>
        <input id="name" type="text" name="name" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <input id="email" type="email" name="email" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="phone" class="form-label">Phone</label>
        <input id="phone" type="text" name="phone" class="form-control">
      </div>

      <div class="mb-3">
        <label for="address" class="form-label">Address</label>
        <textarea id="address" name="address" class="form-control" rows="2"></textarea>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input id="password" type="password" name="password" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Register As</label><br>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="role" id="roleBuyer" value="buyer" checked>
          <label class="form-check-label" for="roleBuyer">Buyer</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="role" id="roleSeller" value="seller">
          <label class="form-check-label" for="roleSeller">Seller</label>
        </div>
      </div>

      <button type="submit" class="btn btn-earth w-100">Register</button>
    </form>

    <p class="text-center mt-3 mb-0">
      Already have an account? 
      <a href="login.php">Log in here</a>
    </p>
  </div>

</body>
</html>
