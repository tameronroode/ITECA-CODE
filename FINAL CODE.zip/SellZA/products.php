<?php

session_start();
require __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}


$category_id = isset($_GET['category']) && ctype_digit($_GET['category'])
    ? (int)$_GET['category'] : null;

$search = isset($_GET['search']) && trim($_GET['search']) !== ''
    ? trim($_GET['search']) : null;

$catName = '';
if ($category_id) {
    $cstmt = $conn->prepare("SELECT name FROM categories WHERE category_id = ?");
    $cstmt->bind_param('i', $category_id);
    $cstmt->execute();
    $cstmt->bind_result($catName);
    $cstmt->fetch();
    $cstmt->close();
}


$where = [];
$params = [];
$types = '';


if ($category_id) {
    $where[]    = 'category_id = ?';
    $types     .= 'i';
    $params[]   = $category_id;
}
if ($search) {
    $where[]    = '(name LIKE ? OR description LIKE ?)';
    $types     .= 'ss';
    $params[]   = "%{$search}%";
    $params[]   = "%{$search}%";
}

$sql = "SELECT product_id, name, price, image
          FROM products";

if (count($where) > 0) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$prods = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SellZA Marketplace</title>


  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
  <?php include 'header.php'; ?>

  <section class="container py-5">
    <h2 class="section-title mb-4">
      <?php
        if ($search && $category_id) {
          echo "Results in “".htmlspecialchars($catName)."” for “".htmlspecialchars($search)."”";
        } elseif ($search) {
          echo "Search results for “".htmlspecialchars($search)."”";
        } elseif ($category_id) {
          echo "Products in “".htmlspecialchars($catName)."”";
        } else {
          echo "All Products";
        }
      ?>
    </h2>

    <?php if ($prods->num_rows === 0): ?>
      <p class="text-center">No products match your criteria.</p>
    <?php else: ?>
      <div class="row g-3 justify-content-center">
        <?php while ($p = $prods->fetch_assoc()): ?>
          <div class="col-6 col-sm-4 col-md-3 col-lg-2">
            <div class="card-earth text-center">
              <div class="card-img-container mx-auto">
                <img
                  src="uploads/<?= htmlspecialchars($p['image']) ?>"
                  alt="<?= htmlspecialchars($p['name']) ?>"
                  class="product-img"
                />
              </div>
              <div class="card-body p-2">
                <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
                <p class="card-text mb-2">R <?= number_format($p['price'], 2) ?></p>
                <a
                  href="product_detail.php?id=<?= $p['product_id'] ?>"
                  class="btn-earth"
                >
                  <i class="fa fa-eye"></i>
                </a>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </section>

  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>

