<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: products.php');
    exit;
}
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login – SellZA</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    body, html {
      height: 100%;
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: #fdf6ef;
      position: relative;
      min-height: 100vh;
    }
    .bg-img {
      position: fixed;
      top: 0; left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 0;
      object-fit: cover;
      filter: brightness(0.65) blur(0px) saturate(1.05);
    }
    .overlay-text {
      position: absolute;
      top: 50%;
      left: 7vw;
      z-index: 2;
      transform: translateY(-50%);
      color: #fff;
      text-shadow: 0 6px 32px rgba(40,30,10,0.25);
      font-size: 3rem;
      font-weight: bold;
      letter-spacing: 2px;
      width: 38vw;
      min-width: 320px;
      max-width: 540px;
      line-height: 1.13;
    }
    .logo-bar {
      position: absolute;
      top: 2.2rem; left: 5vw;
      z-index: 4;
      display: flex;
      align-items: center;
      gap: 1.2rem;
    }
    .logo-bar img {
      height: 60px;
      width: 60px;
      object-fit: contain;
    }
    .logo-bar span {
      color: #fff;
      font-size: 2.25rem;
      font-weight: 700;
      text-shadow: 0 3px 22px rgba(40,30,10,0.20);
      letter-spacing: 1px;
    }
    .about-link {
      position: absolute;
      top: 2.7rem; right: 5vw;
      z-index: 4;
    }
    .about-link a {
      color: #fff;
      font-size: 1.1rem;
      font-weight: 500;
      background: rgba(190,150,80,0.18);
      padding: 8px 16px;
      border-radius: 32px;
      text-decoration: none;
      transition: background 0.17s;
    }
    .about-link a:hover {
      background: rgba(160,120,60,0.32);
      color: #fff;
    }

    
    .login-container {
      position: relative;
      z-index: 10;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      padding-right: 7vw;
    }
    .login-card {
      width: 410px;
      background: rgba(255,255,255,0.95);
      border-radius: 2.5rem;
      box-shadow: 0 8px 48px 0 rgba(120,90,30,0.14);
      padding: 2.6rem 2.1rem 1.6rem 2.1rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 510px;
    }
    .login-card .logo {
      height: 65px;
      width: 65px;
      margin-bottom: 1.2rem;
      margin-top: -1.2rem;
    }
    .tab-btns {
      width: 100%;
      display: flex;
      margin-bottom: 2.1rem;
      justify-content: center;
    }
    .tab-btn {
      background: none;
      border: none;
      font-size: 1.2rem;
      font-weight: 600;
      padding: 0.5rem 2.2rem;
      cursor: pointer;
      color: #a1742a;
      border-bottom: 3px solid transparent;
      transition: border-bottom 0.22s;
    }
    .tab-btn.active {
      color: #4a3728;
      border-bottom: 3px solid #a1742a;
    }
    .login-card form {
      width: 100%;
    }
    .login-card .form-control {
      background: #fff;
      border-radius: 1.2rem;
      border: 1px solid #e2cbb4;
      font-size: 1.08rem;
      margin-bottom: 1.5rem;
      padding: 0.85rem 1.2rem;
    }
    .login-card .btn-earth {
      width: 100%;
      background: #a1742a;
      color: #fff;
      border: none;
      border-radius: 2.1rem;
      font-size: 1.16rem;
      font-weight: 600;
      padding: 0.85rem 0;
      margin-bottom: 1rem;
      transition: background 0.17s;
    }
    .login-card .btn-earth:hover {
      background: #4a3728;
    }
    .login-card .alert {
      margin-bottom: 1.1rem;
      width: 100%;
    }
    .card-footer-links {
      text-align: center;
      margin-top: 1.3rem;
      font-size: 1.03rem;
    }
    .card-footer-links a {
      color: #a1742a;
      text-decoration: underline;
      font-weight: 500;
    }
    .login-card .copyright {
      text-align: center;
      color: #c4ae96;
      font-size: 0.97rem;
      margin-top: 1.7rem;
    }
    @media (max-width: 980px) {
      .overlay-text, .logo-bar { display: none; }
      .login-container { justify-content: center; padding-right: 0; }
    }
    @media (max-width: 480px) {
      .login-card { width: 98vw; min-width: unset; border-radius: 1rem; }
    }
  </style>
</head>
<body>
  <img src="assets/images/login.back.png" alt="Login Background" class="bg-img">

  <div class="logo-bar">
    <img src="assets/images/logo.png" alt="SellZA logo">
    <span>SellZA</span>
  </div>

  <div class="overlay-text">
    Empowering Local Trade
  </div>

  <div class="login-container">
    <div class="login-card" id="login-card">
      <img src="assets/images/logo.png" alt="SellZA logo" class="logo">
      <div class="tab-btns mb-4">
        <button class="tab-btn active" id="tab-login" type="button" onclick="switchTab('login')">Sign In</button>
        <button class="tab-btn" id="tab-register" type="button" onclick="switchTab('register')">Register</button>
      </div>
      
      <form id="form-login" method="post" action="auth.php" autocomplete="on">
        <?php if($error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <input type="hidden" name="action" value="login">
        <label class="mb-1">Email address</label>
        <input type="email" name="email" class="form-control" required>
        <label class="mb-1">Password</label>
        <input type="password" name="password" class="form-control" required>
        <button class="btn-earth mt-1" type="submit">Log In</button>
      </form>
      
      <form id="form-register" method="post" action="auth.php" style="display:none;">
        <input type="hidden" name="action" value="register">
        <label class="mb-1">Full Name</label>
        <input type="text" name="name" class="form-control" required>
        <label class="mb-1">Email address</label>
        <input type="email" name="email" class="form-control" required>
        <label class="mb-1">Phone</label>
        <input type="text" name="phone" class="form-control">
        <label class="mb-1">Address</label>
        <input type="text" name="address" class="form-control">
        <label class="mb-1">Password</label>
        <input type="password" name="password" class="form-control" required>
        <div class="mb-2"></div>
        <div class="mb-3">
          <label class="mb-2 me-2">Register As</label>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="role" value="buyer" checked>
            <label class="form-check-label">Buyer</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="role" value="seller">
            <label class="form-check-label">Seller</label>
          </div>
        </div>
        <button class="btn-earth mt-1" type="submit">Register</button>
      </form>
      <div class="card-footer-links">
        <a href="about.php">About SellZA</a>
      </div>
      <div class="copyright mt-2">&copy; 2025 SellZA. All rights reserved.</div>
    </div>
  </div>
  <script>
  
    function switchTab(tab) {
      const loginBtn = document.getElementById('tab-login');
      const regBtn = document.getElementById('tab-register');
      const loginForm = document.getElementById('form-login');
      const regForm = document.getElementById('form-register');
      if(tab === 'login') {
        loginBtn.classList.add('active');
        regBtn.classList.remove('active');
        loginForm.style.display = '';
        regForm.style.display = 'none';
      } else {
        loginBtn.classList.remove('active');
        regBtn.classList.add('active');
        loginForm.style.display = 'none';
        regForm.style.display = '';
      }
    }
  </script>
</body>
</html>

