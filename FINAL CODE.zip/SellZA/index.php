<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Uploads</title>
</head>
<body>
  <h1>Uploads Folder</h1>
  <p>Files in this folder:</p>
  <ul>
    <li><a href="example.jpg">example.jpg</a></li>
    <li><a href="another.png">another.png</a></li>
    
  </ul>
</body>
</html>
