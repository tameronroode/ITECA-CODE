<?php

session_start();
require __DIR__ . '/includes/db.php';

if (empty($_GET['id']) || !ctype_digit($_GET['id'])) {
    header('Location: products.php');
    exit;
}
$pid = (int)$_GET['id'];

$stmt = $conn->prepare("
    SELECT
        p.product_id,
        p.name,
        p.description,
        p.price,
        p.image,
        c.name AS category_name,
        u.user_id   AS seller_id,
        u.name      AS seller_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.category_id
    JOIN users u ON p.user_id = u.user_id
    WHERE p.product_id = ?
");
$stmt->bind_param('i', $pid);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();


if (!$product) {
    header('Location: products.php');
    exit;
}


function formatRand($amount) {
    return 'R ' . number_format($amount, 2);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= htmlspecialchars($product['name']) ?> — SellZA</title>

  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >

  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <?php include 'header.php'; ?>

  <main class="container my-5">
    <div class="row">
      <div class="col-md-6 mb-4">
        <img
          src="uploads/<?= htmlspecialchars($product['image']) ?>"
          alt="<?= htmlspecialchars($product['name']) ?>"
          class="img-fluid rounded"
        >
      </div>

      <div class="col-md-6">
        <h2 class="mb-3"><?= htmlspecialchars($product['name']) ?></h2>
        <p class="text-muted mb-1">
          <em>Category: <?= htmlspecialchars($product['category_name']) ?></em>
        </p>
        <p class="mb-3">
          Sold by
          <a href="seller_profile.php?user_id=<?= $product['seller_id'] ?>">
            <?= htmlspecialchars($product['seller_name']) ?>
          </a>
        </p>
        <h4 class="text-earth mb-4"><?= formatRand($product['price']) ?></h4>
        <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>

        <div class="mt-4">
          <?php if (isset($_SESSION['user_id'])): ?>
            <a
              href="messenger.php?user=<?= $product['seller_id'] ?>"
              class="btn-earth btn-sm me-2"
            ><i class="fas fa-comments"></i> Message Seller</a>

            <form method="post" action="wishlist.php" class="d-inline me-2">
              <input type="hidden" name="product_id" value="<?= $pid ?>">
              <button class="btn-outline-earth btn-sm">
                <i class="fas fa-heart"></i> Wishlist
              </button>
            </form>

            <form method="post" action="cart.php" class="d-inline me-2">
              <input type="hidden" name="product_id" value="<?= $pid ?>">
              <button class="btn-outline-earth btn-sm">
                <i class="fas fa-shopping-cart"></i> Add to Cart
              </button>
            </form>

            <form method="post" action="checkout.php" class="d-inline">
              <input type="hidden" name="product_id" value="<?= $pid ?>">
              <button class="btn-earth btn-sm">
                <i class="fas fa-credit-card"></i> Buy Now
              </button>
            </form>
          <?php else: ?>
            <button
              class="btn-earth btn-sm"
              data-bs-toggle="modal"
              data-bs-target="#authModal"
            ><i class="fas fa-sign-in-alt"></i> Sign in to purchase</button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </main>

  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>



