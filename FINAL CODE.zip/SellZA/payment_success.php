<?php
session_start();
require __DIR__ . '/includes/db.php';
include 'header.php';

$orderSuccessMessage = $_SESSION['success'] ?? 'Your order has been placed successfully!';
unset($_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Successful — SellZA</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<main class="container my-5 text-center">
  <div class="alert alert-success py-4">
    <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
    <h2 class="mb-3">Payment Successful!</h2>
    <p class="lead"><?= htmlspecialchars($orderSuccessMessage) ?></p>
    <a href="profile.php#order-history" class="btn btn-earth mt-3">
      <i class="fas fa-box-open me-1"></i> View My Orders
    </a>
    <a href="products.php" class="btn btn-outline-secondary mt-3 ms-2">
      <i class="fas fa-store me-1"></i> Continue Shopping
    </a>
  </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php include 'footer.php'; ?>
</body>
</html>
