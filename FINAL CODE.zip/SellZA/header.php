<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require __DIR__ . '/includes/db.php';


$error   = $_SESSION['error']   ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error'], $_SESSION['success']);


$role = $_SESSION['role'] ?? 'guest';
$name = $_SESSION['name'] ?? 'Guest';


$cats = $conn->query("SELECT category_id, name FROM categories ORDER BY name");
?>

<?php if ($error): ?>
  <div class="alert alert-danger text-center m-0">
    <?= htmlspecialchars($error) ?>
  </div>
<?php endif; ?>
<?php if ($success): ?>
  <div class="alert alert-success text-center m-0">
    <?= htmlspecialchars($success) ?>
  </div>
<?php endif; ?>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm py-2">
  <div class="container-fluid">
    <a class="navbar-brand brand-text" href="products.php">SellZA</a>
    <button
      class="navbar-toggler"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#mainNav"
      aria-label="Toggle navigation"
    >
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle"
            href="#"
            id="catBtn"
            role="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            Categories
          </a>
          <ul class="dropdown-menu" aria-labelledby="catBtn">
            <li>
              <a class="dropdown-item" href="products.php">
                See All Products
              </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <?php while ($cat = $cats->fetch_assoc()): ?>
              <li>
                <a
                  class="dropdown-item"
                  href="products.php?category=<?= urlencode($cat['category_id']) ?>"
                >
                  <?= htmlspecialchars($cat['name']) ?>
                </a>
              </li>
            <?php endwhile; ?>
          </ul>
        </li>
      </ul>

      
      <form class="d-flex flex-grow-1 me-4" method="get" action="products.php">
        <input
          class="form-control form-control-lg me-2"
          type="search"
          id="searchInput"
          name="search"
          placeholder="Search for anything…"
          aria-label="Search"
          autocomplete="off"
          list="suggestions"
        >
        <datalist id="suggestions"></datalist>
        <button class="btn btn-earth btn-lg" type="submit">
          <i class="fas fa-search"></i>
        </button>
      </form>

      
      <ul class="navbar-nav d-flex align-items-center mb-2 mb-lg-0">
        <?php if ($role === 'guest'): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="modal" data-bs-target="#authModal">
              Sign In / Register
            </a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <span class="nav-link">Hi, <?= htmlspecialchars($name) ?></span>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="profile.php" title="My Profile">
              <i class="fas fa-user-circle fa-lg"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="wishlist.php" title="Wishlist">
              <i class="fas fa-heart fa-lg"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="cart.php" title="Cart">
              <i class="fas fa-shopping-cart fa-lg"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="messenger.php" title="Chat">
              <i class="fas fa-comments fa-lg"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php" title="Log Out">
              <i class="fas fa-sign-out-alt fa-lg"></i>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>


<script>
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('searchInput');
  const list  = document.getElementById('suggestions');
  let timer;

  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (!q) return list.innerHTML = '';

    timer = setTimeout(() => {
      fetch('search_suggest.php?q=' + encodeURIComponent(q))
        .then(res => res.json())
        .then(arr => {
          list.innerHTML = '';
          arr.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            list.appendChild(opt);
          });
        })
        .catch(()=>{/* silently fail */});
    }, 300);
  });
});
</script>
