<?php
session_start();
require __DIR__ . '/includes/db.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Please sign in to use your cart.';
    header('Location: products.php');
    exit;
}

$user_id = $_SESSION['user_id'];

#Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['product_id'])) {
    $pid = (int)$_POST['product_id'];
    $stmt = $conn->prepare("
      INSERT INTO cart_items (user_id, product_id, quantity)
      VALUES (?, ?, 1)
      ON DUPLICATE KEY UPDATE quantity = quantity + 1
    ");
    $stmt->bind_param('ii', $user_id, $pid);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = 'Added to your cart!';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

 #Remove from Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['remove_id'])) {
    $remove_pid = (int)$_POST['remove_id'];
    $stmt = $conn->prepare("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param('ii', $user_id, $remove_pid);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = 'Item removed from your cart!';
    header('Location: cart.php');
    exit;
}

#Fetch current cart contents
$stmt = $conn->prepare("
    SELECT p.product_id,
           p.name,
           p.price,
           p.image,
           c.quantity
      FROM cart_items c
      JOIN products p ON c.product_id = p.product_id
     WHERE c.user_id = ?
     ORDER BY c.added_at DESC
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();
$items = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Your Cart — SellZA</title>
  <!-- Bootstrap CSS -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >
  <!-- Font Awesome -->
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  <!-- Custom styles -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <?php include 'header.php'; ?>

  <main class="container my-5">
    <h2 class="section-title mb-4">Your Cart</h2>

    <?php if (empty($items)): ?>
      <p class="text-center">Your cart is empty.</p>
    <?php else: ?>
      <div class="product-grid d-flex flex-wrap gap-4 justify-content-center">
        <?php foreach ($items as $p): ?>
          <div class="card-earth position-relative">
            <div class="card-img-container">
              <img
                src="uploads/<?= htmlspecialchars($p['image']) ?>"
                alt="<?= htmlspecialchars($p['name']) ?>"
              />
            </div>
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
              <p class="card-text">Qty: <?= $p['quantity'] ?></p>
              <p class="card-text fw-bold">
                R <?= number_format($p['price'] * $p['quantity'], 2) ?>
              </p>
              <a
                href="checkout.php"
                class="btn-earth btn-sm mt-auto"
              ><i class="fas fa-credit-card"></i> Checkout</a>
              <!-- Remove from cart button -->
              <form method="post" class="mt-2">
                <input type="hidden" name="remove_id" value="<?= $p['product_id'] ?>">
                <button
                  type="submit"
                  class="btn btn-outline-danger btn-sm"
                  title="Remove from cart"
                  onclick="return confirm('Remove this item from your cart?');"
                  style="width:38px; height:38px;"
                >
                  <i class="fas fa-trash"></i>
                </button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>
