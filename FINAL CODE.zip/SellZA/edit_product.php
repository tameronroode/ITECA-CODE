
<?php

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    header('Location: products.php');
    exit;
}
require __DIR__ . '/includes/db.php';


$user_id = (int)$_SESSION['user_id'];
$id      = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("
    SELECT name, description, price, category_id, image
      FROM products
     WHERE product_id = ? AND user_id = ?
");
$stmt->bind_param('ii', $id, $user_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    header('Location: my_listings.php');
    exit;
}
$p = $res->fetch_assoc();
$stmt->close();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name']);
    $desc        = trim($_POST['description']);
    $price       = floatval($_POST['price']);
    $category_id = $_POST['category'];

    
    $image = $p['image'];
    if (!empty($_FILES['image']['name'])) {
        $tmp = $_FILES['image']['tmp_name'];
        $fn  = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($tmp, __DIR__ . "/uploads/$fn");
        $image = $fn;
    }

    $up = $conn->prepare("
        UPDATE products
           SET name = ?, description = ?, price = ?, category_id = ?, image = ?
         WHERE product_id = ? AND user_id = ?
    ");
    $up->bind_param(
        'ssdssii',
        $name,
        $desc,
        $price,
        $category_id,
        $image,
        $id,
        $user_id
    );
    if ($up->execute()) {
        $_SESSION['success'] = 'Product updated!';
        header('Location: my_listings.php');
        exit;
    } else {
        $_SESSION['error'] = 'Update failed: ' . $up->error;
    }
    $up->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Edit Product — SellZA</title>
  
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  >

  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  >
  
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <?php include 'header.php'; ?>

  <div class="container my-5" style="max-width: 600px;">
    <h2 class="section-title mb-4">Edit Product</h2>

    <?php if (!empty($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Name</label>
        <input
          type="text"
          name="name"
          class="form-control"
          value="<?= htmlspecialchars($p['name']) ?>"
          required
        >
      </div>

      <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea
          name="description"
          class="form-control"
          rows="3"
          required
        ><?= htmlspecialchars($p['description']) ?></textarea>
      </div>

      <div class="mb-3">
        <label class="form-label">Price (R)</label>
        <input
          type="number"
          name="price"
          step="0.01"
          class="form-control"
          value="<?= htmlspecialchars($p['price']) ?>"
          required
        >
      </div>

      <div class="mb-3">
        <label class="form-label">Category</label>
        <select name="category" class="form-select" required>
          <?php
            
            $cats = $conn->query("SELECT category_id, name FROM categories ORDER BY name");
            while ($cat = $cats->fetch_assoc()):
          ?>
            <option
              value="<?= htmlspecialchars($cat['category_id']) ?>"
              <?= $cat['category_id'] == $p['category_id'] ? 'selected' : '' ?>
            >
              <?= htmlspecialchars($cat['name']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Image</label><br>
        <img
          src="uploads/<?= htmlspecialchars($p['image']) ?>"
          alt=""
          style="max-width:100px; margin-bottom:1rem;"
        ><br>
        <input type="file" name="image" class="form-control">
        <small class="text-muted">Leave blank to keep existing image.</small>
      </div>

      <button type="submit" class="btn-earth">Save Changes</button>
    </form>
  </div>


  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  ></script>
</body>
</html>

