<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$result = $conn->query("SELECT product_id, name, price, created_at FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product Report</title>
</head>
<body>
  <h2>Product Report</h2>
  <table border="1" cellpadding="10">
    <tr>
      <th>ID</th><th>Name</th><th>Price</th><th>Created</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['product_id'] ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td>R <?= number_format($row['price'], 2) ?></td>
        <td><?= $row['created_at'] ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>